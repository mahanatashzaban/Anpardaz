import {
  useCallback, useEffect, useMemo, useRef, useState, type ReactNode,
} from "react";

// ─── Types ────────────────────────────────────────────────────────────────────

type AppState = "splash" | "login" | "otp" | "onboard-photo" | "onboard-profile" | "onboard-pin" | "ready";
type Tab = "home" | "history" | "profile";
type BoxMode = "exchange" | "transfer";
type ProfileModal = "info" | "help" | "support" | "addcard" | "addcard-form" | null;

interface UserData {
  phone: string; name: string; family: string; nationalId: string;
  birthDate: string; photo: string; pin: string;
  tomanBalance: number; usdtBalance: number;
  cards: BankCard[]; registeredAt: string;
}

interface BankCard { id: string; number: string; bank: string; holderName: string; }

interface TxRecord {
  id: string; userId: string; type: "deposit" | "withdraw" | "swap" | "transfer";
  fromAsset: "toman" | "usdt"; toAsset: "toman" | "usdt";
  amount: number; convertedAmount?: number; fee: number;
  status: "pending" | "done" | "failed"; createdAt: string;
  toAddress?: string; note?: string;
}

// ─── Storage ──────────────────────────────────────────────────────────────────

const DB = {
  getUser: (phone: string): UserData | null => {
    try { return JSON.parse(localStorage.getItem(`anp_user_${phone}`) ?? "null"); } catch { return null; }
  },
  saveUser: (u: UserData) => localStorage.setItem(`anp_user_${u.phone}`, JSON.stringify(u)),
  currentPhone: () => localStorage.getItem("anp_current") ?? "",
  setCurrentPhone: (p: string) => localStorage.setItem("anp_current", p),
  getTx: (phone: string): TxRecord[] => {
    try { return JSON.parse(localStorage.getItem(`anp_tx_${phone}`) ?? "[]"); } catch { return []; }
  },
  saveTx: (phone: string, txs: TxRecord[]) => localStorage.setItem(`anp_tx_${phone}`, JSON.stringify(txs)),
  userExists: (phone: string) => !!localStorage.getItem(`anp_user_${phone}`),
};

// ─── API ──────────────────────────────────────────────────────────────────────

const FALLBACK_RATE = 87500;
const KAVENEGAR_KEY = ""; // کلید API کاوه‌نگار را اینجا وارد کنید

async function fetchUSDTRate(): Promise<number> {
  try {
    const r = await fetch("https://api.wallex.ir/v1/markets", { signal: AbortSignal.timeout(7000) });
    const d = await r.json();
    const p = d?.result?.symbols?.USDTTMN?.stats?.lastPrice
           ?? d?.result?.symbols?.USDTTMN?.stats?.bidPrice;
    if (p) return parseFloat(p);
    return FALLBACK_RATE;
  } catch { return FALLBACK_RATE; }
}

async function sendOTP(phone: string, code: string): Promise<{ ok: boolean; devCode?: string }> {
  if (!KAVENEGAR_KEY) return { ok: false, devCode: code };
  try {
    const url = `https://api.kavenegar.com/v1/${KAVENEGAR_KEY}/sms/send.json`;
    const body = new URLSearchParams({ receptor: phone, message: `کد تأیید ان‌پرداز: ${code}`, sender: "10004346" });
    const r = await fetch(url, { method: "POST", body });
    const d = await r.json();
    return { ok: d.return?.status === 200 };
  } catch { return { ok: false, devCode: code }; }
}

// ─── Utilities ────────────────────────────────────────────────────────────────

const fa = (v: number | string) => new Intl.NumberFormat("fa-IR").format(Number(v));
const faFixed = (v: number, d = 4) => new Intl.NumberFormat("fa-IR", { minimumFractionDigits: d, maximumFractionDigits: d }).format(v);

function genOTP() { return String(Math.floor(100000 + Math.random() * 900000)); }
function genId() { return "TX" + Date.now().toString(36).toUpperCase(); }

function isBSCAddress(s: string) { return /^0x[0-9a-fA-F]{40}$/.test(s.trim()); }
function isIranPhone(s: string) { return /^09[0-9]{9}$/.test(s.trim()); }

function playChime() {
  try {
    const ctx = new AudioContext();
    [523, 659, 784, 1047].forEach((f, i) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.connect(g); g.connect(ctx.destination);
      o.frequency.value = f; o.type = "sine";
      g.gain.setValueAtTime(0, ctx.currentTime + i * 0.11);
      g.gain.linearRampToValueAtTime(0.15, ctx.currentTime + i * 0.11 + 0.03);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.11 + 0.42);
      o.start(ctx.currentTime + i * 0.11); o.stop(ctx.currentTime + i * 0.11 + 0.5);
    });
  } catch {}
}

// ─── Icon ─────────────────────────────────────────────────────────────────────

function Icon({ name, size = 22, stroke = 1.8 }: { name: string; size?: number; stroke?: number }) {
  const P: Record<string, ReactNode> = {
    bell: <><path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"/><path d="M10 21h4"/></>,
    scan: <><path d="M3 8V5a2 2 0 0 1 2-2h3M21 8V5a2 2 0 0 0-2-2h-3M3 16v3a2 2 0 0 0 2 2h3M21 16v3a2 2 0 0 1-2 2h-3"/><path d="M8 12h8"/></>,
    eye: <><path d="M2 12s3.5-6 10-6 10 6 10 6-3.5 6-10 6S2 12 2 12Z"/><circle cx="12" cy="12" r="2.5"/></>,
    "eye-off": <><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/></>,
    plus: <path d="M12 5v14M5 12h14"/>,
    send: <><path d="m21 3-7 18-4-8-7-4 18-6Z"/><path d="m10 13 4-4"/></>,
    swap: <><path d="M7 7h12l-3-3M17 17H5l3 3"/></>,
    receipt: <><path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3Z"/><path d="M9 8h6M9 12h6"/></>,
    home: <><path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V10Z"/><path d="M9 21v-6h6v6"/></>,
    chart: <><path d="M4 19V5M4 19h17"/><path d="m7 15 4-4 3 2 5-6"/></>,
    user: <><circle cx="12" cy="8" r="4"/><path d="M4 21c.8-4 3.4-6 8-6s7.2 2 8 6"/></>,
    arrow: <path d="m14 6-6 6 6 6"/>,
    "arrow-left": <path d="m10 18 6-6-6-6"/>,
    check: <path d="m5 12 4 4L19 6"/>,
    clock: <><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>,
    camera: <><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/></>,
    shield: <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>,
    info: <><circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/></>,
    lock: <><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></>,
    x: <><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></>,
    "alert-circle": <><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>,
    credit: <><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></>,
    phone: <><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 13a19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 3.55 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></>,
    question: <><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3M12 17h.01"/></>,
    wallet: <><path d="M4 7a2 2 0 0 1 2-2h12v14H6a2 2 0 0 1-2-2V7Z"/><path d="M18 9h3v7h-3a2 2 0 0 1 0-4h3"/></>,
    chevron: <path d="m9 18 6-6-6-6"/>,
    delete: <path d="M20 5H9l-7 7 7 7h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2z"/>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{P[name]}</svg>;
}

// ─── Skeleton ─────────────────────────────────────────────────────────────────

function Skeleton() {
  return <main className="phone-shell skeleton" aria-label="در حال بارگذاری">
    <div className="skeleton-bar top"/><div className="skeleton-hero"/>
    <div className="skeleton-actions">{[1,2,3,4].map(i => <div key={i}><i/><b/></div>)}</div>
    <div className="skeleton-line wide"/><div className="skeleton-line"/>
    <div className="skeleton-list">{[1,2,3].map(i => <div key={i}><i/><span/><b/></div>)}</div>
  </main>;
}

// ─── Splash ───────────────────────────────────────────────────────────────────

function SplashScreen() {
  return <div className="splash">
    <div className="splash-inner">
      <div className="splash-logo">
        <div className="splash-mark">ا</div>
        <div className="splash-ripple r1"/><div className="splash-ripple r2"/><div className="splash-ripple r3"/>
      </div>
      <div className="splash-name">ان‌پرداز</div>
      <p className="splash-sub">مدیریت دارایی دیجیتال</p>
    </div>
    <div className="splash-dots"><span/><span/><span/></div>
  </div>;
}

// ─── Phone Login ──────────────────────────────────────────────────────────────

function PhoneLogin({ onSend }: { onSend: (phone: string, code: string, devCode?: string) => void }) {
  const [phone, setPhone] = useState("");
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const submit = async () => {
    const p = phone.trim();
    if (!isIranPhone(p)) { setErr("شماره موبایل معتبر نیست."); return; }
    setErr(""); setLoading(true);
    const code = genOTP();
    const res = await sendOTP(p, code);
    setLoading(false);
    onSend(p, code, res.devCode);
  };

  return <div className="auth-screen" dir="rtl">
    <div className="auth-card">
      <div className="auth-logo"><span className="brand-mark">ا</span><span>ان‌پرداز</span></div>
      <h2>ورود به حساب</h2>
      <p className="auth-desc">شماره موبایل خود را وارد کنید. کد تأیید برایتان پیامک می‌شود.</p>
      <div className="field-group">
        <label>شماره موبایل</label>
        <input className="text-input ltr" value={phone} onChange={e => setPhone(e.target.value)} placeholder="09xxxxxxxxx" inputMode="tel" maxLength={11} dir="ltr" onKeyDown={e => e.key === "Enter" && submit()}/>
      </div>
      {err && <p className="field-err">{err}</p>}
      <button className="primary-button" onClick={submit} disabled={loading}>
        {loading ? "در حال ارسال..." : "دریافت کد تأیید"}
      </button>
    </div>
  </div>;
}

// ─── OTP Verify ───────────────────────────────────────────────────────────────

function OTPVerify({ phone, correctCode, devCode, onVerified }: {
  phone: string; correctCode: string; devCode?: string;
  onVerified: (phone: string) => void;
}) {
  const [otp, setOtp] = useState("");
  const [err, setErr] = useState("");
  const [resendLeft, setResendLeft] = useState(120);

  useEffect(() => {
    if (resendLeft <= 0) return;
    const t = setTimeout(() => setResendLeft(r => r - 1), 1000);
    return () => clearTimeout(t);
  }, [resendLeft]);

  const verify = () => {
    if (otp.trim() === correctCode) { onVerified(phone); }
    else { setErr("کد وارد شده اشتباه است."); }
  };

  const pad = (n: number) => String(Math.floor(n / 60)).padStart(2, "0") + ":" + String(n % 60).padStart(2, "0");

  return <div className="auth-screen" dir="rtl">
    <div className="auth-card">
      <div className="auth-logo"><span className="brand-mark">ا</span><span>ان‌پرداز</span></div>
      <h2>کد تأیید</h2>
      <p className="auth-desc">کد ۶ رقمی ارسال‌شده به <b dir="ltr">{phone}</b> را وارد کنید.</p>
      {devCode && <div className="dev-code-hint">⚠️ حالت آزمایشی — کد: <b dir="ltr">{devCode}</b></div>}
      <div className="field-group">
        <label>کد تأیید</label>
        <input className="text-input otp-input ltr" value={otp} onChange={e => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))} placeholder="______" inputMode="numeric" dir="ltr" onKeyDown={e => e.key === "Enter" && verify()}/>
      </div>
      {err && <p className="field-err">{err}</p>}
      <button className="primary-button" onClick={verify}>تأیید و ورود</button>
      <p className="resend-row">
        {resendLeft > 0 ? <span>ارسال مجدد تا <b dir="ltr">{pad(resendLeft)}</b></span> : <button className="link-btn" onClick={() => setResendLeft(120)}>ارسال مجدد کد</button>}
      </p>
    </div>
  </div>;
}

// ─── Onboard Photo ────────────────────────────────────────────────────────────

function OnboardPhoto({ onDone }: { onDone: (photo: string) => void }) {
  const [photo, setPhoto] = useState("");
  const [cameraOn, setCameraOn] = useState(false);
  const [err, setErr] = useState("");
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "user" } });
      if (videoRef.current) { videoRef.current.srcObject = stream; videoRef.current.play(); }
      setCameraOn(true);
    } catch { setErr("دسترسی به دوربین رد شد. لطفاً تصویر آپلود کنید."); }
  };

  const snap = () => {
    if (!videoRef.current || !canvasRef.current) return;
    const v = videoRef.current, c = canvasRef.current;
    c.width = v.videoWidth; c.height = v.videoHeight;
    c.getContext("2d")?.drawImage(v, 0, 0);
    const url = c.toDataURL("image/jpeg", 0.8);
    setPhoto(url);
    (v.srcObject as MediaStream)?.getTracks().forEach(t => t.stop());
    setCameraOn(false);
  };

  return <div className="auth-screen" dir="rtl">
    <div className="auth-card">
      <div className="onboard-step">مرحله ۱ از ۳</div>
      <h2>عکس پروفایل</h2>
      <p className="auth-desc">برای استفاده از اپ، ابتدا از چهره خود عکس بگیرید یا تصویر آپلود کنید.</p>
      <div className="photo-circle">
        {photo ? <img src={photo} alt="پروفایل"/> : cameraOn ? <video ref={videoRef} autoPlay playsInline muted className="camera-feed"/> : <Icon name="camera" size={40}/>}
      </div>
      <canvas ref={canvasRef} style={{ display: "none" }}/>
      {!photo && !cameraOn && <div className="btn-row">
        <button className="outline-button" onClick={startCamera}><Icon name="camera" size={16}/> دوربین</button>
        <button className="outline-button" onClick={() => fileRef.current?.click()}><Icon name="plus" size={16}/> آپلود</button>
        <input ref={fileRef} type="file" accept="image/*" style={{ display: "none" }} onChange={e => { const f = e.target.files?.[0]; if (!f) return; const r = new FileReader(); r.onload = ev => setPhoto(ev.target?.result as string); r.readAsDataURL(f); }}/>
      </div>}
      {cameraOn && <button className="primary-button" style={{ marginTop: 16 }} onClick={snap}>📸 ثبت عکس</button>}
      {err && <p className="field-err">{err}</p>}
      {photo && <button className="primary-button" onClick={() => onDone(photo)}>ادامه <Icon name="arrow" size={18}/></button>}
    </div>
  </div>;
}

// ─── Onboard Profile ──────────────────────────────────────────────────────────

function OnboardProfile({ onDone }: { onDone: (d: { name: string; family: string; nationalId: string; birthDate: string }) => void }) {
  const [d, setD] = useState({ name: "", family: "", nationalId: "", birthDate: "" });
  const [err, setErr] = useState("");

  const confirm = () => {
    if (!d.name || !d.family || !d.nationalId || !d.birthDate) { setErr("تمام فیلدها الزامی است."); return; }
    if (d.nationalId.length !== 10) { setErr("کد ملی باید ۱۰ رقم باشد."); return; }
    setErr(""); onDone(d);
  };

  return <div className="auth-screen" dir="rtl">
    <div className="auth-card">
      <div className="onboard-step">مرحله ۲ از ۳</div>
      <h2>اطلاعات شخصی</h2>
      <p className="auth-desc">اطلاعات زیر برای احراز هویت لازم است.</p>
      <div className="profile-form">
        {([["نام", "name", "text"], ["نام خانوادگی", "family", "text"], ["کد ملی", "nationalId", "numeric"], ["تاریخ تولد", "birthDate", "text"]] as [string, keyof typeof d, string][]).map(([label, key, mode]) =>
          <label key={key}>{label}<input className={`text-input ${key === "nationalId" || key === "birthDate" ? "ltr" : ""}`} value={d[key]} onChange={e => setD(p => ({ ...p, [key]: e.target.value }))} inputMode={mode as never} placeholder={key === "nationalId" ? "۱۰ رقم" : key === "birthDate" ? "۱۴۰۰/۰۱/۰۱" : ""}/></label>
        )}
      </div>
      {err && <p className="field-err">{err}</p>}
      <button className="primary-button" onClick={confirm}>ادامه <Icon name="arrow" size={18}/></button>
    </div>
  </div>;
}

// ─── Onboard PIN ──────────────────────────────────────────────────────────────

function OnboardPin({ onDone }: { onDone: (pin: string) => void }) {
  const [step, setStep] = useState<"enter" | "confirm">("enter");
  const [first, setFirst] = useState("");
  const [cur, setCur] = useState("");
  const [err, setErr] = useState("");

  const tap = (d: string) => {
    const next = cur + d;
    if (next.length > 4) return;
    setCur(next);
    if (next.length === 4) {
      setTimeout(() => {
        if (step === "enter") { setFirst(next); setCur(""); setStep("confirm"); setErr(""); }
        else { if (next === first) { onDone(next); } else { setErr("رمزها یکسان نیستند."); setFirst(""); setCur(""); setStep("enter"); } }
      }, 150);
    }
  };

  const del = () => setCur(p => p.slice(0, -1));

  const KEYS = ["1","2","3","4","5","6","7","8","9","","0","del"];
  const FA_DIG: Record<string, string> = {"1":"۱","2":"۲","3":"۳","4":"۴","5":"۵","6":"۶","7":"۷","8":"۸","9":"۹","0":"۰"};

  return <div className="auth-screen" dir="rtl">
    <div className="auth-card pin-card">
      <div className="onboard-step">مرحله ۳ از ۳</div>
      <div className="pin-lock"><Icon name="lock" size={30}/></div>
      <h2>{step === "enter" ? "رمز ۴ رقمی بسازید" : "تأیید رمز"}</h2>
      <p className="auth-desc">{step === "enter" ? "یک رمز ۴ رقمی برای امنیت حساب انتخاب کنید." : "رمز را یک‌بار دیگر وارد کنید."}</p>
      <div className="pin-dots">{[0,1,2,3].map(i => <div key={i} className={`pin-dot ${cur.length > i ? "filled" : ""}`}/>)}</div>
      {err && <p className="field-err">{err}</p>}
      <div className="pin-pad">
        {KEYS.map((k, i) => k === "" ? <div key={i}/> : k === "del" ? <button key={i} className="pin-key del" onClick={del}><Icon name="delete" size={18}/></button> : <button key={i} className="pin-key" onClick={() => tap(k)}>{FA_DIG[k]}</button>)}
      </div>
    </div>
  </div>;
}

// ─── Exchange Box ─────────────────────────────────────────────────────────────

function ExchangeBox({ user, rate, onUpdate }: {
  user: UserData; rate: number; onUpdate: (u: UserData, tx: TxRecord) => void;
}) {
  const [from, setFrom] = useState<"toman" | "usdt">("toman");
  const [amount, setAmount] = useState("");
  const [err, setErr] = useState("");
  const [cooldown, setCooldown] = useState(0);
  const to = from === "toman" ? "usdt" : "toman";
  const numAmount = parseFloat(amount) || 0;
  const converted = from === "toman" ? numAmount / rate : numAmount * rate;

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown(c => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  const submit = () => {
    if (cooldown > 0) return;
    if (numAmount <= 0) { setErr("مبلغ معتبر وارد کنید."); return; }
    if (from === "toman" && numAmount > user.tomanBalance) { setErr("موجودی تومانی کافی نیست."); return; }
    if (from === "usdt" && numAmount > user.usdtBalance) { setErr("موجودی USDT کافی نیست."); return; }
    setErr("");
    const tx: TxRecord = { id: genId(), userId: user.phone, type: "swap", fromAsset: from, toAsset: to, amount: numAmount, convertedAmount: converted, fee: 0, status: "pending", createdAt: new Date().toISOString() };
    const updated: UserData = { ...user,
      tomanBalance: from === "toman" ? user.tomanBalance - numAmount : user.tomanBalance + converted,
      usdtBalance: from === "usdt" ? user.usdtBalance - numAmount : user.usdtBalance + converted,
    };
    onUpdate(updated, tx);
    setAmount(""); setCooldown(600); playChime();
  };

  const padT = (n: number) => String(Math.floor(n / 60)).padStart(2, "0") + ":" + String(n % 60).padStart(2, "0");

  return <>
    <div className="ex-assets">
      <button className={`ex-asset-btn ${from === "toman" ? "active" : ""}`} onClick={() => setFrom("toman")}>
        <span className="ex-symbol toman">﷼</span><div><small>تومان</small><b>{fa(user.tomanBalance)}</b></div>
      </button>
      <button className={`ex-asset-btn ${from === "usdt" ? "active" : ""}`} onClick={() => setFrom("usdt")}>
        <span className="ex-symbol usdt">₮</span><div><small>تتر USDT</small><b>{faFixed(user.usdtBalance)}</b></div>
      </button>
    </div>

    <div className="exchange-input">
      <label>از</label>
      <div className="currency-chip">
        <span className={from}>{from === "toman" ? "﷼" : "₮"}</span>
        {from === "toman" ? "تومان" : "تتر"}
      </div>
      <input value={amount} onChange={e => setAmount(e.target.value.replace(/[^0-9.]/g, ""))} inputMode="decimal" placeholder="۰" aria-label="مبلغ"/>
    </div>

    <button className="swap-dir-btn" onClick={() => setFrom(to)} aria-label="تعویض">
      <Icon name="swap" size={18}/>
    </button>

    <div className="exchange-input destination">
      <label>به</label>
      <div className="currency-chip">
        <span className={to}>{to === "toman" ? "﷼" : "₮"}</span>
        {to === "toman" ? "تومان" : "تتر"}
      </div>
      <output>{numAmount > 0 ? (to === "usdt" ? converted.toFixed(6) : fa(Math.round(converted))) : "—"}</output>
    </div>

    <div className="rate-row">
      <span>نرخ Wallex</span><b>{fa(Math.round(rate))} تومان</b>
    </div>

    {err && <p className="field-err inline">{err}</p>}

    {cooldown > 0
      ? <div className="cooldown-btn"><Icon name="clock" size={16}/> تراکنش بعدی: <b>{padT(cooldown)}</b></div>
      : <button className="primary-button" onClick={submit}>تأیید تبدیل <Icon name="arrow" size={18}/></button>
    }
  </>;
}

// ─── Transfer Box ─────────────────────────────────────────────────────────────

function TransferBox({ user, rate, onUpdate }: {
  user: UserData; rate: number; onUpdate: (u: UserData, tx: TxRecord) => void;
}) {
  const [asset, setAsset] = useState<"toman" | "usdt">("toman");
  const [dest, setDest] = useState("");
  const [amount, setAmount] = useState("");
  const [msg, setMsg] = useState<{ text: string; type: "err" | "ok" | "warn" } | null>(null);
  const [loading, setLoading] = useState(false);
  const [cooldown, setCooldown] = useState(0);
  const numAmount = parseFloat(amount) || 0;

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown(c => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  const destType: "mobile" | "bsc" | "unknown" = isIranPhone(dest.trim()) ? "mobile" : isBSCAddress(dest.trim()) ? "bsc" : "unknown";

  const submit = async () => {
    setMsg(null);
    if (cooldown > 0) return;
    if (!dest.trim()) { setMsg({ text: "آدرس مقصد را وارد کنید.", type: "err" }); return; }
    if (destType === "unknown") { setMsg({ text: "آدرس مقصد معتبر نیست. شماره موبایل یا آدرس BSC وارد کنید.", type: "err" }); return; }
    if (numAmount <= 0) { setMsg({ text: "مبلغ معتبر وارد کنید.", type: "err" }); return; }
    const fee = asset === "usdt" && destType === "bsc" ? 1 : 0;
    const total = numAmount + fee;
    if (asset === "toman" && total > user.tomanBalance) { setMsg({ text: "موجودی کافی نیست.", type: "err" }); return; }
    if (asset === "usdt" && total > user.usdtBalance) { setMsg({ text: "موجودی USDT کافی نیست (شامل کارمزد ۱ USDT).", type: "err" }); return; }

    if (destType === "mobile") {
      setLoading(true);
      const exists = DB.userExists(dest.trim());
      setLoading(false);
      if (!exists) { setMsg({ text: "شماره موبایل وارد‌شده کاربر ان‌پرداز نیست.", type: "err" }); return; }
    }

    const tx: TxRecord = { id: genId(), userId: user.phone, type: "transfer", fromAsset: asset, toAsset: asset, amount: numAmount, fee, status: destType === "bsc" ? "pending" : "done", createdAt: new Date().toISOString(), toAddress: dest.trim(), note: destType === "bsc" ? "انتقال به شبکه BSC" : "انتقال داخلی" };
    const updated: UserData = { ...user,
      tomanBalance: asset === "toman" ? user.tomanBalance - total : user.tomanBalance,
      usdtBalance: asset === "usdt" ? user.usdtBalance - total : user.usdtBalance,
    };
    onUpdate(updated, tx);
    setDest(""); setAmount(""); setCooldown(600); playChime();
    setMsg({ text: destType === "bsc" ? "در حال ارسال به شبکه BSC... وضعیت در تراکنش‌ها قابل پیگیری است." : "انتقال با موفقیت انجام شد.", type: "ok" });
  };

  const padT = (n: number) => String(Math.floor(n / 60)).padStart(2, "0") + ":" + String(n % 60).padStart(2, "0");

  return <>
    <div className="ex-assets">
      <button className={`ex-asset-btn ${asset === "toman" ? "active" : ""}`} onClick={() => setAsset("toman")}>
        <span className="ex-symbol toman">﷼</span><div><small>تومان</small><b>{fa(user.tomanBalance)}</b></div>
      </button>
      <button className={`ex-asset-btn ${asset === "usdt" ? "active" : ""}`} onClick={() => setAsset("usdt")}>
        <span className="ex-symbol usdt">₮</span><div><small>تتر USDT</small><b>{faFixed(user.usdtBalance)}</b></div>
      </button>
    </div>

    <div className="field-group-inline">
      <label>آدرس مقصد</label>
      <input className="text-input ltr" value={dest} onChange={e => setDest(e.target.value)} placeholder="09xxxxxxxxx یا 0x..." dir="ltr"/>
      {dest && <div className="dest-type-badge">
        {destType === "mobile" ? "👤 کاربر ان‌پرداز" : destType === "bsc" ? "🔗 آدرس BSC" : "⚠️ نامعتبر"}
      </div>}
    </div>

    <div className="exchange-input" style={{ marginTop: 10 }}>
      <label>مبلغ</label>
      <div className="currency-chip"><span className={asset}>{asset === "toman" ? "﷼" : "₮"}</span>{asset === "toman" ? "تومان" : "تتر"}</div>
      <input value={amount} onChange={e => setAmount(e.target.value.replace(/[^0-9.]/g, ""))} inputMode="decimal" placeholder="۰"/>
    </div>

    {asset === "usdt" && destType === "bsc" && <div className="fee-note"><Icon name="info" size={13}/> کارمزد شبکه: ۱ USDT</div>}

    {msg && <p className={`field-err inline ${msg.type}`}>{msg.text}</p>}

    {cooldown > 0
      ? <div className="cooldown-btn"><Icon name="clock" size={16}/> تراکنش بعدی: <b>{padT(cooldown)}</b></div>
      : <button className="primary-button" onClick={submit} disabled={loading}>
          {loading ? "در حال بررسی..." : "تأیید انتقال"} {!loading && <Icon name="arrow" size={18}/>}
        </button>
    }
  </>;
}

// ─── Asset Details Modal ──────────────────────────────────────────────────────

function AssetModal({ user, rate, onClose }: { user: UserData; rate: number; onClose: () => void }) {
  const totalInToman = user.tomanBalance + user.usdtBalance * rate;
  return <div className="modal-overlay" onClick={onClose}>
    <div className="modal-card" onClick={e => e.stopPropagation()}>
      <div className="modal-handle"/>
      <h3>جزئیات دارایی</h3>
      <div className="asset-detail-row">
        <div className="asset-detail-icon toman">﷼</div>
        <div><p>تومان ایران</p><strong>{fa(user.tomanBalance)} <small>تومان</small></strong></div>
      </div>
      <div className="asset-detail-row">
        <div className="asset-detail-icon usdt">₮</div>
        <div><p>تتر (USDT · BSC)</p><strong>{faFixed(user.usdtBalance)} <small>USDT</small></strong><br/><small className="sub">≈ {fa(Math.round(user.usdtBalance * rate))} تومان</small></div>
      </div>
      <div className="asset-total-row">
        <span>ارزش کل دارایی</span>
        <b>{fa(Math.round(totalInToman))} تومان</b>
      </div>
      <div className="rate-row" style={{ marginTop: 12 }}>
        <span>نرخ USDT (Wallex)</span><b>{fa(Math.round(rate))} تومان</b>
      </div>
      <button className="primary-button" onClick={onClose}>بستن</button>
    </div>
  </div>;
}

// ─── Tx Modal ────────────────────────────────────────────────────────────────

function TxModal({ tx, onClose }: { tx: TxRecord; onClose: () => void }) {
  const typeLabel: Record<string, string> = { swap: "تبدیل", transfer: "انتقال", deposit: "واریز", withdraw: "برداشت" };
  const statusLabel: Record<string, string> = { done: "انجام‌شده", pending: "در انتظار بررسی", failed: "ناموفق" };
  const dt = new Date(tx.createdAt);
  const timeStr = dt.toLocaleDateString("fa-IR") + " · " + dt.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });
  return <div className="modal-overlay" onClick={onClose}>
    <div className="modal-card" onClick={e => e.stopPropagation()}>
      <div className="modal-handle"/>
      <h3>{typeLabel[tx.type] ?? tx.type}</h3>
      <p className="modal-status">{statusLabel[tx.status]}</p>
      <div className="modal-detail"><span>شناسه</span><b dir="ltr">{tx.id}</b></div>
      <div className="modal-detail"><span>زمان</span><b>{timeStr}</b></div>
      <div className="modal-detail"><span>مبلغ</span><b>{fa(tx.amount)} {tx.fromAsset === "toman" ? "تومان" : "USDT"}</b></div>
      {tx.convertedAmount != null && <div className="modal-detail"><span>معادل</span><b>{tx.toAsset === "usdt" ? tx.convertedAmount.toFixed(6) : fa(Math.round(tx.convertedAmount))} {tx.toAsset === "toman" ? "تومان" : "USDT"}</b></div>}
      {tx.fee > 0 && <div className="modal-detail"><span>کارمزد</span><b>{tx.fee} USDT</b></div>}
      {tx.toAddress && <div className="modal-detail"><span>مقصد</span><b dir="ltr">{tx.toAddress}</b></div>}
      <button className="primary-button" onClick={onClose}>بستن</button>
    </div>
  </div>;
}

// ─── Help Modal ───────────────────────────────────────────────────────────────

const HELP_STEPS = [
  { icon: "wallet", title: "کیف پول دیجیتال", body: "در صفحه اصلی، موجودی تومان و تتر (USDT در شبکه BSC) خود را مشاهده می‌کنید." },
  { icon: "plus", title: "افزایش موجودی", body: "با کلیک روی «افزایش موجودی» می‌توانید از طریق درگاه بانکی، کیف پول تومانی خود را شارژ کنید." },
  { icon: "swap", title: "تبدیل دارایی", body: "با کلیک «تبدیل ارز»، تومان خود را به تتر یا تتر را به تومان تبدیل کنید. نرخ لحظه‌ای از صرافی والکس دریافت می‌شود." },
  { icon: "send", title: "انتقال دارایی", body: "با «انتقال» می‌توانید تومان یا تتر را به کاربر دیگر (با موبایل) یا به آدرس BSC ارسال کنید." },
  { icon: "chart", title: "تراکنش‌ها", body: "تمام تراکنش‌های شما در این بخش نمایش داده می‌شود و می‌توانید وضعیت هر کدام را پیگیری کنید." },
  { icon: "credit", title: "کارت بانکی", body: "در پروفایل می‌توانید کارت‌های بانکی خود را ثبت کنید تا شارژ تومان سریع‌تر انجام شود." },
];

function HelpModal({ onClose }: { onClose: () => void }) {
  const [step, setStep] = useState(0);
  const s = HELP_STEPS[step];
  return <div className="modal-overlay" onClick={onClose}>
    <div className="modal-card help-modal" onClick={e => e.stopPropagation()}>
      <div className="modal-handle"/>
      <div className="help-icon"><Icon name={s.icon} size={30}/></div>
      <h3>{s.title}</h3>
      <p className="help-body">{s.body}</p>
      <div className="help-dots">{HELP_STEPS.map((_, i) => <span key={i} className={i === step ? "active" : ""}/>)}</div>
      <div className="help-nav">
        {step > 0 && <button className="outline-button sm" onClick={() => setStep(p => p - 1)}>قبلی</button>}
        <div style={{ flex: 1 }}/>
        {step < HELP_STEPS.length - 1
          ? <button className="primary-button sm" onClick={() => setStep(p => p + 1)}>بعدی</button>
          : <button className="primary-button sm" onClick={onClose}>متوجه شدم</button>
        }
      </div>
    </div>
  </div>;
}

// ─── Support Modal ────────────────────────────────────────────────────────────

function SupportModal({ onClose }: { onClose: () => void }) {
  return <div className="modal-overlay" onClick={onClose}>
    <div className="modal-card" onClick={e => e.stopPropagation()}>
      <div className="modal-handle"/>
      <h3>پشتیبانی</h3>
      <p className="auth-desc">برای راهنمایی و پشتیبانی با شماره‌های زیر تماس بگیرید.</p>
      <a href="tel:09375437106" className="support-call-btn"><Icon name="phone" size={20}/>۰۹۳۷۵۴۳۷۱۰۶</a>
      <a href="tel:09051826963" className="support-call-btn"><Icon name="phone" size={20}/>۰۹۰۵۱۸۲۶۹۶۳</a>
      <button className="outline-button" style={{ width: "100%", marginTop: 8 }} onClick={onClose}>بستن</button>
    </div>
  </div>;
}

// ─── Add Card Modal ───────────────────────────────────────────────────────────

function AddCardModal({ onAdd, onClose }: { onAdd: (c: BankCard) => void; onClose: () => void }) {
  const [num, setNum] = useState("");
  const [bank, setBank] = useState("");
  const [holder, setHolder] = useState("");
  const [err, setErr] = useState("");

  const fmt = (v: string) => v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();

  const save = () => {
    if (num.replace(/\s/g,"").length !== 16) { setErr("شماره کارت باید ۱۶ رقم باشد."); return; }
    if (!bank || !holder) { setErr("تمام فیلدها الزامی است."); return; }
    onAdd({ id: genId(), number: num.replace(/\s/g,""), bank, holderName: holder });
  };

  return <div className="modal-overlay" onClick={onClose}>
    <div className="modal-card" onClick={e => e.stopPropagation()}>
      <div className="modal-handle"/>
      <h3>افزودن کارت بانکی</h3>
      <div className="profile-form">
        <label>شماره کارت<input className="text-input ltr" value={fmt(num)} onChange={e => setNum(e.target.value.replace(/\s/g,""))} inputMode="numeric" placeholder="xxxx xxxx xxxx xxxx" dir="ltr"/></label>
        <label>نام بانک<input className="text-input" value={bank} onChange={e => setBank(e.target.value)} placeholder="مثلاً ملت"/></label>
        <label>نام صاحب کارت<input className="text-input" value={holder} onChange={e => setHolder(e.target.value)}/></label>
      </div>
      {err && <p className="field-err">{err}</p>}
      <button className="primary-button" onClick={save}>ذخیره کارت</button>
      <button className="outline-button" style={{ width:"100%", marginTop:8 }} onClick={onClose}>انصراف</button>
    </div>
  </div>;
}

// ─── Profile Page ─────────────────────────────────────────────────────────────

function ProfilePage({ user, onUpdate, onLogout }: { user: UserData; onUpdate: (u: UserData) => void; onLogout: () => void }) {
  const [modal, setModal] = useState<ProfileModal>(null);

  const initials = (user.name?.[0] ?? "") + (user.family?.[0] ?? "") || "؟";

  return <>
    <section className="subpage profile">
      <div className="profile-avatar">
        {user.photo ? <img src={user.photo} alt="پروفایل"/> : initials}
      </div>
      <p>حساب کاربری</p>
      <h1>{(user.name + " " + user.family).trim() || "کاربر"}</h1>
      <span className="verified"><Icon name="check" size={14}/> احراز هویت شده</span>
      <div className="profile-menu">
        <button onClick={() => setModal("info")}><span><Icon name="user" size={16}/> اطلاعات شخصی</span><Icon name="arrow-left" size={16}/></button>
        <button onClick={() => setModal("addcard")}><span><Icon name="credit" size={16}/> کارت‌های بانکی</span><Icon name="arrow-left" size={16}/></button>
        <button onClick={() => setModal("help")}><span><Icon name="question" size={16}/> راهنمای اپ</span><Icon name="arrow-left" size={16}/></button>
        <button onClick={() => setModal("support")}><span><Icon name="phone" size={16}/> پشتیبانی</span><Icon name="arrow-left" size={16}/></button>
        <button onClick={onLogout} className="logout-btn"><span><Icon name="x" size={16}/> خروج از حساب</span></button>
      </div>
    </section>

    {modal === "info" && <div className="modal-overlay" onClick={() => setModal(null)}>
      <div className="modal-card" onClick={e => e.stopPropagation()}>
        <div className="modal-handle"/>
        <h3>اطلاعات شخصی</h3>
        <div className="info-field"><span>نام</span><b>{user.name || "—"}</b></div>
        <div className="info-field"><span>نام خانوادگی</span><b>{user.family || "—"}</b></div>
        <div className="info-field"><span>کد ملی</span><b dir="ltr">{user.nationalId || "—"}</b></div>
        <div className="info-field"><span>تاریخ تولد</span><b dir="ltr">{user.birthDate || "—"}</b></div>
        <div className="info-field"><span>موبایل</span><b dir="ltr">{user.phone}</b></div>
        <div className="info-field"><span>عضویت</span><b>{user.registeredAt ? new Date(user.registeredAt).toLocaleDateString("fa-IR") : "—"}</b></div>
        <button className="primary-button" onClick={() => setModal(null)}>بستن</button>
      </div>
    </div>}

    {modal === "addcard" && <div className="modal-overlay" onClick={() => setModal(null)}>
      <div className="modal-card" onClick={e => e.stopPropagation()}>
        <div className="modal-handle"/>
        <h3>کارت‌های بانکی</h3>
        {user.cards.length === 0 && <p className="empty-state">کارتی ثبت نشده است.</p>}
        {user.cards.map(c => <div key={c.id} className="card-item">
          <Icon name="credit" size={18}/>
          <div><b dir="ltr">{c.number.replace(/(.{4})/g,"$1 ").trim()}</b><small>{c.bank} · {c.holderName}</small></div>
        </div>)}
        <button className="outline-button" style={{ width:"100%", marginTop:8 }} onClick={() => setModal("addcard-form")}>+ افزودن کارت</button>
        <button className="primary-button" style={{ marginTop:8 }} onClick={() => setModal(null)}>بستن</button>
      </div>
    </div>}

    {modal === "addcard-form" && <AddCardModal
      onAdd={c => { const updated = { ...user, cards: [...user.cards, c] }; onUpdate(updated); setModal(null); }}
      onClose={() => setModal(null)}
    />}

    {modal === "help" && <HelpModal onClose={() => setModal(null)}/>}
    {modal === "support" && <SupportModal onClose={() => setModal(null)}/>}
  </>;
}

// ─── History Page ────────────────────────────────────────────────────────────

function TxRow({ tx, onClick }: { tx: TxRecord; onClick: () => void }) {
  const typeLabel: Record<string, string> = { swap: "تبدیل دارایی", transfer: "انتقال", deposit: "واریز", withdraw: "برداشت" };
  const toneMap: Record<string, string> = { swap: "sand", transfer: "peach", deposit: "mint", withdraw: "olive" };
  const iconMap: Record<string, string> = { swap: "swap", transfer: "send", deposit: "plus", withdraw: "send" };
  const dt = new Date(tx.createdAt);
  const timeStr = dt.toLocaleDateString("fa-IR") + "، " + dt.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });
  return <article className="transaction" onClick={onClick} style={{ cursor: "pointer" }}>
    <span className={`transaction-icon ${toneMap[tx.type] ?? "mint"}`}>
      <Icon name={tx.status === "pending" ? "clock" : (iconMap[tx.type] ?? "receipt")} size={20}/>
    </span>
    <div><strong>{typeLabel[tx.type] ?? tx.type}</strong><small>{timeStr}</small></div>
    <b className={tx.status === "pending" ? "pending" : ""}>{tx.status === "pending" ? "در انتظار" : `${fa(tx.amount)} ${tx.fromAsset === "toman" ? "تومان" : "USDT"}`}</b>
  </article>;
}

function HistoryPage({ transactions, onBack }: { transactions: TxRecord[]; onBack: () => void }) {
  const [filter, setFilter] = useState("همه");
  const [selected, setSelected] = useState<TxRecord | null>(null);
  const filters = ["همه", "تبدیل", "انتقال", "واریز"];
  const typeMap: Record<string, string> = { تبدیل: "swap", انتقال: "transfer", واریز: "deposit" };
  const filtered = filter === "همه" ? transactions : transactions.filter(t => t.type === typeMap[filter]);

  return <section className="subpage">
    <button onClick={onBack} className="back"><Icon name="arrow"/> بازگشت</button>
    <p>پیگیری آسان</p><h1>تراکنش‌های شما</h1>
    <div className="filter-pills">{filters.map(f => <button key={f} className={filter === f ? "selected" : ""} onClick={() => setFilter(f)}>{f}</button>)}</div>
    {filtered.length === 0 ? <p className="empty-state">تراکنشی یافت نشد.</p>
      : <section className="transactions full">{filtered.map(tx => <TxRow key={tx.id} tx={tx} onClick={() => setSelected(tx)}/>)}</section>}
    {selected && <TxModal tx={selected} onClose={() => setSelected(null)}/>}
  </section>;
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [appState, setAppState] = useState<AppState>("splash");
  const [pendingPhone, setPendingPhone] = useState("");
  const [pendingCode, setPendingCode] = useState("");
  const [pendingDevCode, setPendingDevCode] = useState<string | undefined>();
  const [user, setUser] = useState<UserData | null>(null);
  const [tab, setTab] = useState<Tab>("home");
  const [boxMode, setBoxMode] = useState<BoxMode>("exchange");
  const [rate, setRate] = useState(FALLBACK_RATE);
  const [rateLoading, setRateLoading] = useState(true);
  const [showBal, setShowBal] = useState(true);
  const [assetModal, setAssetModal] = useState(false);
  const [transactions, setTransactions] = useState<TxRecord[]>([]);
  const [selectedTx, setSelectedTx] = useState<TxRecord | null>(null);

  // Splash timer
  useEffect(() => {
    const t = setTimeout(() => {
      const phone = DB.currentPhone();
      if (phone) { const u = DB.getUser(phone); if (u) { setUser(u); setTransactions(DB.getTx(phone)); setAppState("ready"); return; } }
      setAppState("login");
    }, 2200);
    return () => clearTimeout(t);
  }, []);

  // Live rate
  useEffect(() => {
    fetchUSDTRate().then(r => { setRate(r); setRateLoading(false); });
    const iv = setInterval(() => fetchUSDTRate().then(setRate), 60000);
    return () => clearInterval(iv);
  }, []);

  const updateUser = useCallback((u: UserData) => {
    DB.saveUser(u); setUser(u);
  }, []);

  const updateWithTx = useCallback((u: UserData, tx: TxRecord) => {
    const txs = [tx, ...transactions];
    DB.saveUser(u); DB.saveTx(u.phone, txs);
    setUser(u); setTransactions(txs);
  }, [transactions]);

  const handleVerified = (phone: string) => {
    DB.setCurrentPhone(phone);
    const existing = DB.getUser(phone);
    if (existing) { setUser(existing); setTransactions(DB.getTx(phone)); setAppState("ready"); }
    else setAppState("onboard-photo");
  };

  const handleLogout = () => {
    DB.setCurrentPhone("");
    setUser(null); setTransactions([]); setTab("home"); setAppState("login");
  };

  // ── Onboarding state machine
  const [obPhoto, setObPhoto] = useState("");
  const [obProfile, setObProfile] = useState({ name: "", family: "", nationalId: "", birthDate: "" });

  if (appState === "splash") return <SplashScreen/>;
  if (appState === "login") return <PhoneLogin onSend={(phone, code, dev) => { setPendingPhone(phone); setPendingCode(code); setPendingDevCode(dev); setAppState("otp"); }}/>;
  if (appState === "otp") return <OTPVerify phone={pendingPhone} correctCode={pendingCode} devCode={pendingDevCode} onVerified={handleVerified}/>;
  if (appState === "onboard-photo") return <OnboardPhoto onDone={p => { setObPhoto(p); setAppState("onboard-profile"); }}/>;
  if (appState === "onboard-profile") return <OnboardProfile onDone={d => { setObProfile(d); setAppState("onboard-pin"); }}/>;
  if (appState === "onboard-pin") return <OnboardPin onDone={pin => {
    const u: UserData = { ...obProfile, phone: pendingPhone, photo: obPhoto, pin, tomanBalance: 0, usdtBalance: 0, cards: [], registeredAt: new Date().toISOString() };
    DB.saveUser(u); DB.setCurrentPhone(u.phone); setUser(u); setAppState("ready");
  }}/>;
  if (!user) return null;

  const recentTx = transactions.slice(0, 3);
  const initials = (user.name?.[0] ?? "") + (user.family?.[0] ?? "") || "؟";

  const quickAction = (label: string) => {
    if (label === "تبدیل ارز") { setBoxMode("exchange"); setTab("home"); document.getElementById("action-box")?.scrollIntoView({ behavior: "smooth", block: "nearest" }); }
    else if (label === "انتقال") { setBoxMode("transfer"); setTab("home"); document.getElementById("action-box")?.scrollIntoView({ behavior: "smooth", block: "nearest" }); }
    else if (label === "تراکنش‌ها") setTab("history");
    else if (label === "افزایش موجودی") { /* درگاه پرداخت - آینده */ alert("درگاه شارژ موجودی به‌زودی فعال می‌شود."); }
  };

  return <div className="app" dir="rtl">
    <header className="app-header">
      <div className="header-profile" onClick={() => setTab("profile")}>
        <div className="header-avatar">
          {user.photo ? <img src={user.photo} alt="پروفایل"/> : initials}
        </div>
      </div>
      <div className="brand"><span className="brand-mark">ا</span><span>ان‌پرداز</span></div>
      <button className="icon-button" aria-label="اعلان‌ها"><Icon name="bell"/></button>
    </header>

    <main className="phone-shell">
      {tab === "history" ? <HistoryPage transactions={transactions} onBack={() => setTab("home")}/> :
       tab === "profile" ? <ProfilePage user={user} onUpdate={updateUser} onLogout={handleLogout}/> :
       <>
        {/* Balance Card */}
        <section className="balance-card">
          <div className="balance-top">
            <span>دارایی کل شما</span>
            <button onClick={() => setShowBal(b => !b)} aria-label="نمایش/پنهان موجودی"><Icon name={showBal ? "eye" : "eye-off"} size={18}/></button>
          </div>
          <strong>{showBal ? fa(user.tomanBalance) : "••••••••"}<em> تومان</em></strong>
          <div className="balance-usdt-row">
            <span className="usdt-badge">₮ {showBal ? faFixed(user.usdtBalance, 4) : "••••"} USDT</span>
            <span className="rate-live">
              {rateLoading ? "دریافت نرخ..." : `۱ USDT = ${fa(Math.round(rate))} تومان`}
              <i className="pulse"/>
            </span>
          </div>
          <div className="balance-bottom">
            <button className="detail-btn" onClick={() => setAssetModal(true)}>جزئیات دارایی <Icon name="arrow" size={16}/></button>
          </div>
          <div className="orb one"/><div className="orb two"/>
        </section>

        {/* Quick Actions */}
        <section className="quick-actions" aria-label="دسترسی‌های سریع">
          {[
            { label: "افزایش موجودی", icon: "plus", tone: "mint" },
            { label: "انتقال", icon: "send", tone: "olive", active: boxMode === "transfer" },
            { label: "تبدیل ارز", icon: "swap", tone: "sand", active: boxMode === "exchange" },
            { label: "تراکنش‌ها", icon: "receipt", tone: "peach" },
          ].map(item => <button key={item.label} onClick={() => quickAction(item.label)}>
            <span className={`action-icon ${item.tone} ${item.active ? "action-active" : ""}`}><Icon name={item.icon}/></span>
            <small>{item.label}</small>
          </button>)}
        </section>

        {/* Exchange / Transfer Box */}
        <section id="action-box" className="exchange">
          <div className="exchange-head">
            <div>
              <button className={`box-tab ${boxMode === "exchange" ? "selected" : ""}`} onClick={() => setBoxMode("exchange")}>تبدیل دارایی</button>
              <button className={`box-tab ${boxMode === "transfer" ? "selected" : ""}`} onClick={() => setBoxMode("transfer")}>انتقال دارایی</button>
            </div>
            <span className="secure"><Icon name="shield" size={13}/> امن</span>
          </div>
          {boxMode === "exchange"
            ? <ExchangeBox user={user} rate={rate} onUpdate={updateWithTx}/>
            : <TransferBox user={user} rate={rate} onUpdate={updateWithTx}/>
          }
        </section>

        {/* Recent Transactions */}
        <section className="section-heading history-heading">
          <div><p>آخرین فعالیت‌ها</p><h2>تراکنش‌های اخیر</h2></div>
          <button onClick={() => setTab("history")}>همه <Icon name="arrow" size={17}/></button>
        </section>
        {recentTx.length === 0
          ? <p className="empty-state">هنوز تراکنشی انجام نشده است.</p>
          : <section className="transactions">{recentTx.map(tx => <TxRow key={tx.id} tx={tx} onClick={() => setSelectedTx(tx)}/>)}</section>
        }
       </>}
    </main>

    {/* Bottom Nav — 3 items, RTL */}
    <nav className="bottom-nav">
      {([
        { id: "profile", label: "پروفایل", icon: "user" },
        { id: "history", label: "تراکنش‌ها", icon: "chart" },
        { id: "home", label: "خانه", icon: "home" },
      ] as { id: Tab; label: string; icon: string }[]).map(n =>
        <button key={n.id} onClick={() => setTab(n.id)} className={tab === n.id ? "active" : ""}>
          <Icon name={n.icon}/><span>{n.label}</span>
        </button>
      )}
    </nav>

    {assetModal && <AssetModal user={user} rate={rate} onClose={() => setAssetModal(false)}/>}
    {selectedTx && <TxModal tx={selectedTx} onClose={() => setSelectedTx(null)}/>}
  </div>;
}
